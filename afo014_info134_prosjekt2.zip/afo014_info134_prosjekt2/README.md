# film-bib
Filmbibliotek 


Skoleprosjekt- filmdatabase laget i HTML, CSS og JS.
